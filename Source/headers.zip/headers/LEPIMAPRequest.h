#import <Foundation/Foundation.h>

@protocol LEPIMAPRequestDelegate;

@interface LEPIMAPRequest : NSObject {
}

@property (assign) id <LEPIMAPRequestDelegate> delegate;

- (void) start;
- (void) cancel;
- (NSError *) error;

@end

@protocol LEPIMAPRequestDelegate

- (void) LEPIMAPRequest_finished:(LEPIMAPRequest *)op;

@end

// internal

@interface LEPIMAPRequestQueue : NSObject {
}

@end
