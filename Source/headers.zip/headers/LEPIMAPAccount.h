#import <Foundation/Foundation.h>

typedef enum {
	LEPAuthTypeClear,
	LEPAuthTypeStartTLS,
	LEPAuthTypeTLS,
	LEPAuthTypeSASLCRAMMD5,
	LEPAuthTypeSASLPlain,
	LEPAuthTypeSASLGSSAPI,
	LEPAuthTypeSASLDIGESTMD5,
	LEPAuthTypeSASLLogin,
	LEPAuthTypeSASLSRP,
	LEPAuthTypeSASLNTLM,
	LEPAuthTypeSASLOTP,
	LEPAuthTypeSASLKerberosV4,
} LEPAuthType;

@class LEPIMAPRequest;

@interface LEPIMAPAccount : NSObject {
}

@property (copy) NSString * imapHost;
@property uint16_t imapPort;
@property (copy) NSString * login;
@property (copy) NSString * password;
@property LEPAuthType authType;

@property (copy) NSString * smtpHost;
@property uint16_t smtpPort;
@property (copy) NSString * smtpLogin;
@property (copy) NSString * smtpPassword;
@property LEPAuthType smtpAuthType;

@property (readonly) NSArray * subscribedFolders;
@property (readonly) NSArray * allFolders;

@property BOOL idleEnabled;

// after the operation is created, it should be started
- (LEPIMAPRequest *) fetchSubscribedFoldersRequest;

// after the operation is created, it should be started
- (LEPIMAPRequest *) fetchAllFoldersRequest;

- (LEPIMAPRequest *) createFolderRequest:(NSString *)name;

@end
