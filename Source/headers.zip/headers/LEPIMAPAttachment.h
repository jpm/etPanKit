#import "LEPAbstractAttachment.h"
#import "LEPIMAPRequest.h"

@class LEPIMAPFetchAttachmentRequest;

@interface LEPIMAPAttachment : LEPAbstractAttachment {
}

- (LEPIMAPFetchAttachmentRequest *) fetch;

@end

@interface LEPIMAPFetchAttachmentRequest : LEPIMAPRequest {
}

@property (readonly) NSData * data;

@end
