#import "LEPAbstractMessage.h"

@interface LEPMessage : LEPAbstractMessage {
}

@property (readonly) NSString * stringValue;
@property (readonly) NSData * data;

@property (copy) NSString * messageID;
@property (copy) NSArray * reference;
@property (copy) NSArray * inReplyTo;

@property (copy) NSString * from;
@property (copy) NSArray * to;
@property (copy) NSArray * cc;
@property (copy) NSArray * bcc;
@property (copy) NSString * subject;

@property (copy) NSString * body;
@property (copy) NSArray * /* LEPAttachment */ attachments;

@end

