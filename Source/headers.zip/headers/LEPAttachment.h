#import "LEPAbstractAttachment"

@interface LEPAttachment : LEPAbstractAttachment {
}

@property (copy) filename;
@property (copy) mimeType;

@end
