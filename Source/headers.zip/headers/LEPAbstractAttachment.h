#import <Foundation/Foundation.h>

@interface LEPAbstractAttachment : NSObject {
}

@property (copy, readonly) filename;
@property (copy, readonly) mimeType;

@end
