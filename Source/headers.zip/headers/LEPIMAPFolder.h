#import "LEPIMAPRequest.h"

@class LEPIMAPFetchFolderMessagesRequest;

@interface LEPIMAPFolder : NSObject {
}

@property (readonly) NSString * uidValidity;

- (LEPIMAPRequest *) createFolderRequest:(NSString *)name;
- (LEPIMAPFetchFolderMessagesRequest *) fetchMessagesRequest;
- (LEPIMAPFetchFolderMessagesRequest *) fetchMessagesRequestFromSequenceNumber:(uint32_t)sequenceNumber;
- (LEPIMAPFetchFolderMessagesRequest *) fetchMessagesRequestFromUID:(uint32_t)uid;
- (LEPIMAPRequest *) appendMessageRequest:(LEPAbstractMessage *)message;
- (LEPIMAPRequest *) appendMessagesRequest:(NSArray * /* LEPAbstractMessage */)message;

@end

@interface LEPIMAPFetchFolderMessagesRequest : LEPIMAPRequest {
}

@property (readonly) NSArray * /* LEPIMAPMessage */ messages;

@end
