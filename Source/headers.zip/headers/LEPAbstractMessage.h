#import <Foundation/Foundation.h>

@interface LEPAbstractMessage : NSObject {
}

@property (copy, readonly) NSString * messageID;
@property (copy, readonly) NSArray * reference;
@property (copy, readonly) NSArray * inReplyTo;

@property (copy, readonly) NSString * from;
@property (copy, readonly) NSArray * to;
@property (copy, readonly) NSArray * cc;
@property (copy, readonly) NSArray * bcc;
@property (copy, readonly) NSString * subject;

@end
